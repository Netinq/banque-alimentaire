<header class="col-10 offset-1 row">
    <div class="col-8 col-md-4">
        <a id="title" href="/">
            <img src="<?php echo e(asset('img/logo.png')); ?>" alt="Banque Alimentaire de Bordeaux et de la Gironde">
        </a>
    </div>
    <div class="col-4 d-flex d-md-none burger" id="burger" onclick="display_menu()">
        <div class="bar"></div>
        <div class="bar"></div>
        <div class="bar"></div>
    </div>
    <nav class="col-8 d-none d-md-flex">
        <a href="/">
            <div class="nav-btn">Carte</div>
        </a>
        <a href="/contact">
            <div class="nav-btn">Contact</div>
        </a>
        <?php if(!(Auth::check())): ?>
        <a href="/login" >
            <div class="nav-btn">Me connecter</div>
        </a>
        <a href="/register">
            <div class="nav-btn nav-btn-primary">Créer un compte</div>
        </a>
        <?php else: ?>
        <a href="/panel">
            <div class="nav-btn nav-btn-primary">Mon espace</div>
        </a>
        <?php endif; ?>
    </nav>
    <nav class="d-flex d-md-none nav-mobile hide" id="m_nav">
        <a href="/">
            <div class="nav-btn">Carte</div>
        </a>
        <a href="/contact">
            <div class="nav-btn">Contact</div>
        </a>
        <?php if(!(Auth::check())): ?>
        <a href="/login" >
            <div class="nav-btn">Me connecter</div>
        </a>
        <a href="/register">
            <div class="nav-btn nav-btn-primary">Créer un compte</div>
        </a>
        <?php else: ?>
        <a href="/panel">
            <div class="nav-btn nav-btn-primary">Mon espace</div>
        </a>
        <?php endif; ?>
    </nav>
</header>
<?php /**PATH C:\NETINQ\epsi-workspace\banque-alimentaire\resources\views/layouts/header.blade.php ENDPATH**/ ?>