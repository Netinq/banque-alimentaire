<?php $__env->startSection('content'); ?>
<section class="form-ui col-10 col-sm-8 col-md-6 col-xl-4 offset-1 offset-sm-2 offset-md-3 offset-xl-4">
    <form method="POst" action="<?php echo e(route('volunteer.store')); ?>">
        <?php echo csrf_field(); ?>
        <h1>Devenez volontaire</h1>
        <span>Contribuons tous ensembles pour aider son prochain</span>
        <div class="form-group row col-10">
            <label for="name">Prénom</label>
            <input class="form-control" name="firstname" type="firstname" value="<?php echo e(old('firstname')); ?>" id="firstname">
            <?php $__errorArgs = ['firstname'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p class="invalid-feedback" role="alert">
                    <strong><?php echo e($message); ?></strong>
                </p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class="form-group row col-10">
            <label for="name">Nom</label>
            <input class="form-control" name="lastname" type="lastname" value="<?php echo e(old('lastname')); ?>" id="lastname">
            <?php $__errorArgs = ['lastname'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p class="invalid-feedback" role="alert">
                    <strong><?php echo e($message); ?></strong>
                </p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class="form-group row col-10">
            <label for="name">Code postal</label>
            <input class="form-control" name="zip" type="number" value="<?php echo e(old('zip')); ?>" id="zip">
            <?php $__errorArgs = ['zip'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p class="invalid-feedback" role="alert">
                    <strong><?php echo e($message); ?></strong>
                </p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class="form-group row col-10">
            <label for="name">Ville</label>
            <input class="form-control" name="city" type="text" value="<?php echo e(old('city')); ?>" id="city">
            <?php $__errorArgs = ['city'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p class="invalid-feedback" role="alert">
                    <strong><?php echo e($message); ?></strong>
                </p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class="form-group row col-10 form-bottom">
            <div class="col-6">
                <a href="<?php echo e(url()->previous()); ?>"><div class="btn btn-secondary">Retour</div></a>
            </div>
            <div class="col-6">
                <button type="submit" class="btn btn-primary btn-primary-delmarge">Créer mon espace</button>
            </div>
        </div>

    </form>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', ['styles' => ['auth/auth']], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\NETINQ\epsi-workspace\banque-alimentaire\resources\views/auth/account/step2_volunteer.blade.php ENDPATH**/ ?>