<?php $__env->startSection('description', 'Rejoignez dès maintenant la Banque Alimentaire de Bordeaux. Devenez partenaires ou inscrivez-vous en tant que bénévole afin d\'aider nos partenaires !'); ?>



<!DOCTYPE html>
<html lang="fr">
    <head>
        <!-- Default meta -->
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, height=device-height, initial-scale=1">

        <meta name='author' content='Quentin Sar, Netinq'>
        <meta name='owner' content='Banque Alimentaire'>
        <meta name='subject' content="Quentin Sar">

        <meta name='identifier-URL' content='banque-alimentaire.fr'>
        <meta name="description" content="<?php echo $__env->yieldContent('description'); ?>">
        <meta name='reply-to' content='contact@banque-alimentaire.fr'>

        <meta name='language' content='FR'>
        <meta name='target' content='all'>
        <meta name='theme-color' content='#F26E20'>

        <link rel='shortcut icon' type='image/png' href='<?php echo e(asset('images/logo.png')); ?>'>
        <link rel="apple-touch-icon" href="<?php echo e(asset('images/logo.png')); ?>" />

        <!-- Twitter Card meta -->
        <meta name='twitter:card' content='summary'>
        <meta name="twitter:site" content="@Netinq" />
        <meta name="twitter:title" content="<?php if (! empty(trim($__env->yieldContent('title')))): ?> <?php echo e(Config::get('app.name')); ?> - <?php echo $__env->yieldContent('title'); ?> <?php else: ?> Banque alimentaire de Bordeaux <?php endif; ?>" />
        <meta name='twitter:url' content='https://banque-alimentaire.fr' />
        <meta name='twitter:domain' content='banque-alimentaire.fr' />
        <meta name="twitter:description" content="<?php echo $__env->yieldContent('description'); ?>" />
        <meta name="twitter:image" content="<?php echo e(asset('images/meta.png')); ?>" />

        <!-- Open Graph meta -->
        <meta property='og:title' content='<?php if (! empty(trim($__env->yieldContent('title')))): ?> <?php echo e(Config::get('app.name')); ?> - <?php echo $__env->yieldContent('title'); ?> <?php else: ?> Banque alimentaire de Bordeaux <?php endif; ?>' />
        <meta property="og:description" content="<?php echo $__env->yieldContent('description'); ?>" />
        <meta property="og:image" content="<?php echo e(asset('images/meta.png')); ?>" />
        <meta property='og:type' content='website' />
        <meta property='og:url' content='https://banque-alimentaire.fr' />
        <meta property='og:site_name' content='<?php echo e(Config::get('app.name')); ?>' />
        <meta property="og:locale" content="fr_FR" />

        <!-- IOS meta -->
        <meta name="apple-mobile-web-app-title" content="<?php echo e(Config::get('app.name')); ?>">
        <meta name="apple-mobile-web-app-capable" content="yes" />
        <meta name="apple-mobile-web-app-status-bar-style" content="black-translucent" />

        <title>
            <?php if (! empty(trim($__env->yieldContent('title')))): ?> <?php echo e(Config::get('app.name')); ?> : <?php echo $__env->yieldContent('title'); ?>
            <?php else: ?> Banque alimentaire de Bordeaux <?php endif; ?>
        </title>

        <!-- STATIC Stylesheet -->
        <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/layouts/footer.css')); ?>">
        
        <!-- STATIC Scripts -->
        
        <?php if (! empty(trim($__env->yieldContent('noMaster')))): ?> <?php else: ?>
        <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/master.css')); ?>">
        <?php endif; ?>
        
        <!-- GENERATE Stylesheet -->
        <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
        <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/layouts/header.css')); ?>">

            <?php if($styles ?? null): ?>
            <?php $__currentLoopData = $styles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $style): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <link rel="stylesheet" type="text/css"
            href="<?php echo e(asset('css/'.$style.'.css')); ?>">
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
    </head>

    <body class="row">
        <?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->yieldContent('content'); ?>
        <?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </body>
    <script src="<?php echo e(asset('js/contrast.js')); ?>"></script>
    <script src="<?php echo e(asset('js/menu.js')); ?>"></script>
</html>
<?php /**PATH C:\NETINQ\epsi-workspace\banque-alimentaire\resources\views/layouts/app.blade.php ENDPATH**/ ?>