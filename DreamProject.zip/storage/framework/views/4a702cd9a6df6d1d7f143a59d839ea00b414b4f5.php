

<?php $__env->startSection('content'); ?>
<section class="form-ui col-10 col-sm-8 col-md-6 col-xl-4 offset-1 offset-sm-2 offset-md-3 offset-xl-4">
    <form method="POST" action="<?php echo e(route('partner.store')); ?>">
        <?php echo csrf_field(); ?>
        <h1>Ajouter un partenaire</h1>
        <span>Contribuons tous ensembles pour aider son prochain</span>
<?php if($errors->any()): ?>
    <?php echo e(implode('', $errors->all('<div>:message</div>'))); ?>

<?php endif; ?>
        <div class="form-group row col-10">
            <label for="name">Nom partenaire</label>
            <input class="form-control" name="name" type="text" value="<?php echo e(old('name')); ?>">
            <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p class="invalid-feedback" role="alert">
                    <strong><?php echo e($message); ?></strong>
                </p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class="form-group row col-10">
            <label for="siret">Siret</label>
            <input class="form-control" name="siret" type="text" value="<?php echo e(old('siret')); ?>">
            <?php $__errorArgs = ['siret'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p class="invalid-feedback" role="alert">
                    <strong><?php echo e($message); ?></strong>
                </p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class="form-group row col-10">
            <label for="naf">Naf</label>
            <input class="form-control" name="naf" type="text" value="<?php echo e(old('naf')); ?>">
            <?php $__errorArgs = ['naf'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p class="invalid-feedback" role="alert">
                    <strong><?php echo e($message); ?></strong>
                </p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class="form-group row col-10">
            <label for="adress">Addresse</label>
            <input class="form-control" name="adress" type="text" value="<?php echo e(old('address')); ?>">
            <?php $__errorArgs = ['adress'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p class="invalid-feedback" role="alert">
                    <strong><?php echo e($message); ?></strong>
                </p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class="form-group row col-10">
            <label for="name">Code postal</label>
            <input class="form-control" name="zip" type="number" value="<?php echo e(old('zip')); ?>">
            <?php $__errorArgs = ['zip'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p class="invalid-feedback" role="alert">
                    <strong><?php echo e($message); ?></strong>
                </p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class="form-group row col-10">
            <label for="name">Ville</label>
            <input class="form-control" name="city" type="text" value="<?php echo e(old('city')); ?>">
            <?php $__errorArgs = ['city'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p class="invalid-feedback" role="alert">
                    <strong><?php echo e($message); ?></strong>
                </p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class="form-group row col-10">
            <label for="name">Nombre bénévole max</label>
            <input class="form-control" type="number" name="max_volunteers" value="<?php echo e(old('max_volunteers')); ?>">
            <?php $__errorArgs = ['max_volunteers'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p class="invalid-feedback" role="alert">
                    <strong><?php echo e($message); ?></strong>
                </p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class="form-group col-8">
            <button type="submit" class="btn btn-primary">Soumettre</button>
        </div>


    </form>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', ['styles' => ['auth/auth']], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\NETINQ\epsi-workspace\banque-alimentaire\resources\views/auth/account/step2_partner.blade.php ENDPATH**/ ?>