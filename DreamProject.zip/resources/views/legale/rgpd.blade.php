@extends('layouts.app', ['styles' => ['auth/auth']])

@section('content')
<section class="form-ui col-10 col-sm-8 col-md-6 col-xl-4 offset-1 offset-sm-2 offset-md-3 offset-xl-4 text-left my-4">
    <h1>RGPD</h1>
    <div>
        Commodo non eu nostrud qui aliqua. Ex cillum consectetur pariatur fugiat nulla. Amet exercitation velit aute aliqua. Cillum reprehenderit dolor cupidatat nostrud enim aute veniam Lorem. Nostrud ullamco labore fugiat amet nulla et ea nostrud enim aliquip incididunt ea incididunt. Cupidatat in ex magna excepteur Lorem esse ipsum voluptate eu sunt anim non consequat pariatur.
    </div>
    <h1>Example</h1>
    <div>
        Ut tempor magna cupidatat tempor enim laboris. Ad aliqua non duis tempor ut non nisi laboris in. Tempor fugiat irure nulla occaecat elit velit occaecat. Sit tempor enim id adipisicing velit occaecat tempor veniam. Incididunt laboris et ut aliquip consequat eu eu. In duis ullamco voluptate aliquip.
    </div>
    <h1>Example 2</h1>
    <div>
        Incididunt non culpa sunt anim officia occaecat eu. Lorem irure ipsum laboris Lorem voluptate sint. Enim ullamco esse sunt ullamco laborum labore amet nulla proident reprehenderit aliquip amet.
    </div>
    <h1>Example 3</h1>
    <div>
        Nisi in labore ullamco consequat deserunt tempor proident nulla quis laborum cillum aliquip. Adipisicing occaecat exercitation sit exercitation in ullamco Lorem officia. Ut dolore aliqua exercitation sint sint laborum ipsum laborum duis ut. Commodo dolore nisi culpa et esse fugiat reprehenderit sit eu voluptate pariatur. Excepteur occaecat velit consequat voluptate pariatur magna cupidatat excepteur irure in id id ex. Fugiat tempor ullamco id amet et enim irure cupidatat pariatur excepteur elit nulla. Nostrud Lorem excepteur consectetur tempor reprehenderit anim magna tempor qui.
    </div>
    <h1>Example 4</h1>
    <div>
        Nostrud cillum ea commodo exercitation tempor minim enim sit aute ad est excepteur qui. Quis nulla est proident non. Eiusmod elit velit nisi aliqua nisi ea minim et fugiat laboris dolor mollit commodo. Do irure Lorem anim laboris velit irure qui reprehenderit labore ipsum elit cillum. Eiusmod officia deserunt amet exercitation tempor consequat do aliqua minim eiusmod. Sint sunt eiusmod minim deserunt nostrud excepteur dolore qui ullamco fugiat elit. Sunt do do excepteur aute laboris qui ipsum irure anim consectetur magna Lorem nostrud.
    </div>
    <h1>Example 5</h1>
    <div>
        Id adipisicing magna fugiat consectetur minim exercitation aliqua. Commodo est consectetur laboris in sint ex non aliquip ex nostrud sit cupidatat in ea. Nisi velit irure consequat quis reprehenderit sit in deserunt esse qui nostrud. Consectetur occaecat anim voluptate sint commodo Lorem ut reprehenderit laborum. Incididunt proident sint culpa ullamco eiusmod est.
    </div>
    <h1>Example 6</h1>
    <div>
        Excepteur cupidatat cupidatat consectetur cupidatat. Reprehenderit officia aliqua officia Lorem. Quis aute minim officia laboris dolore. Excepteur veniam in deserunt amet exercitation fugiat est. Est ut cupidatat cillum sunt sunt. Elit reprehenderit Lorem culpa aute elit voluptate labore cillum proident ullamco.
    </div>
</section>
@endsection