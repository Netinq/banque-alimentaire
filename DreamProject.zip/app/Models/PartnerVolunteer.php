<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Partner_Volunteer extends Model
{
    use HasFactory;

    public $timestamps = false;
}
